window.onload = function wallet() {
    let money ='15.00';
    document.getElementById("credit");
    credit.innerHTML = money;

    
}