var selection = document.getElementById("country");
    function select() {
      alert(selection.options[selection.selectedIndex].value);

    }
    
