function signin() {
    console.log("An Error has been found");
}

/* function version() {
    document.getElementById(version);

    if version.value = "Version wählen"{
        alert("Bitte Version wählen");
    }
} */

